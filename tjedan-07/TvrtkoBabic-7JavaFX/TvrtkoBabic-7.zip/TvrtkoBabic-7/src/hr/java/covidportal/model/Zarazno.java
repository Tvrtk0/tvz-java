package hr.java.covidportal.model;

/**
 * Služi za prikaz metoda koja klasa mora implementirat ako koristi ovaj interface.
 */
public interface Zarazno {
    public void prelazakZarazeNaOsobu(Osoba o);
}